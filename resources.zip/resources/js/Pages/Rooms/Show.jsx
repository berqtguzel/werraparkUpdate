import React from "react";
import { Head, usePage } from "@inertiajs/react";
import {
    BedDouble,
    CheckCircle2,
    ChevronLeft,
    ChevronRight,
    Compass,
    MapPin,
    Sparkles,
} from "lucide-react";
import AppLayout from "@/Layouts/AppLayout";
import ROOMS_DATA, { ROOM_LIST } from "@/Data/RoomsData";
import { useTranslation } from "@/i18n";
import "@/../css/room-detail.css";

export default function RoomShow({ room }) {
    const { props } = usePage();
    const rooms = props.rooms;
    const features = props.features;
    const boardTypes = props.boardTypes;
    const boardPrices = props.boardPrices;
    const roomPrices = props.roomPrices;
    console.log("RoomShow props:", props);

    const locale = props?.locale ?? "de";
    const { t } = useTranslation();
    const data = ROOMS_DATA[room] ?? ROOM_LIST[0];

    const images = data.gallery?.length ? data.gallery : [data.heroImage];
    const [activeIndex, setActiveIndex] = React.useState(0);
    const [paused, setPaused] = React.useState(false);
    const activeImage = images[activeIndex];

    React.useEffect(() => {
        setActiveIndex(0);
    }, [data.id]);

    React.useEffect(() => {
        if (paused || images.length <= 1) return;
        const interval = window.setInterval(() => {
            setActiveIndex((prev) => (prev + 1) % images.length);
        }, 4200);
        return () => window.clearInterval(interval);
    }, [images.length, paused, data.id]);

    const goPrev = () =>
        setActiveIndex((prev) => (prev - 1 + images.length) % images.length);
    const goNext = () => setActiveIndex((prev) => (prev + 1) % images.length);

    return (
        <AppLayout currentRoute="rooms">
            <Head title={t("roomDetail.pageTitle", { name: data.hotelName })} />

            <section className="rux-wrap" aria-labelledby="rux-title">
                <div className="rux-grid">
                    <article className="rux-stage-card">
                        <figure
                            className="rux-stage"
                            onMouseEnter={() => setPaused(true)}
                            onMouseLeave={() => setPaused(false)}
                        >
                            <img src={activeImage} alt={data.hotelName} />
                            <div className="rux-overlay" />
                            <figcaption className="rux-caption">
                                {data.atmosphere}
                            </figcaption>

                            {images.length > 1 && (
                                <>
                                    <button
                                        type="button"
                                        className="rux-arrow rux-arrow--left"
                                        onClick={goPrev}
                                        aria-label={t("roomDetail.prevImage")}
                                    >
                                        <ChevronLeft size={18} />
                                    </button>
                                    <button
                                        type="button"
                                        className="rux-arrow rux-arrow--right"
                                        onClick={goNext}
                                        aria-label={t("roomDetail.nextImage")}
                                    >
                                        <ChevronRight size={18} />
                                    </button>
                                </>
                            )}
                        </figure>

                        <div className="rux-thumbs">
                            {images.map((src, index) => (
                                <button
                                    key={`${src}-${index}`}
                                    type="button"
                                    className={`rux-thumb ${
                                        index === activeIndex ? "is-active" : ""
                                    }`}
                                    onClick={() => setActiveIndex(index)}
                                    aria-label={t("roomDetail.imageN", {
                                        n: index + 1,
                                    })}
                                >
                                    <img src={src} alt="" aria-hidden="true" />
                                </button>
                            ))}
                        </div>
                    </article>

                    <aside className="rux-aside">
                        <p className="rux-eyebrow">{t("roomDetail.eyebrow")}</p>
                        <h1 id="rux-title" className="rux-title">
                            {data.hotelName}
                        </h1>
                        <p className="rux-loc">
                            <MapPin size={15} />
                            <span>{data.location}</span>
                        </p>
                        <p className="rux-intro">{data.intro}</p>

                        <div className="rux-facts">
                            {(data.quickFacts || []).map((fact, i) => (
                                <article key={i} className="rux-fact">
                                    <span>{fact.label}</span>
                                    <strong>{fact.value}</strong>
                                </article>
                            ))}
                        </div>

                        <article className="rux-cta">
                            <p className="rux-kicker">
                                {t("roomDetail.idealFor")}
                            </p>
                            <h2>{data.goodFor}</h2>
                            <p>{t("roomDetail.bookingText")}</p>
                            <div className="rux-actions">
                                <a
                                    href={`/${locale}/kontakt`}
                                    className="rux-btn rux-btn--primary"
                                >
                                    {t("roomDetail.requestBtn")}
                                </a>
                                <a href="/" className="rux-btn rux-btn--ghost">
                                    {t("roomDetail.homeBtn")}
                                </a>
                            </div>
                        </article>
                    </aside>
                </div>

                <div className="rux-bottom">
                    <article className="rux-panel">
                        <div className="rux-panel-head">
                            <BedDouble size={17} />
                            <h3>{t("roomDetail.roomCategories")}</h3>
                        </div>
                        <ul className="rux-list">
                            {data.roomTypes.map((item, i) => (
                                <li key={i}>
                                    <CheckCircle2 size={16} />
                                    <span>{item}</span>
                                </li>
                            ))}
                        </ul>
                    </article>

                    <article className="rux-panel rux-panel--amenities">
                        <div className="rux-panel-head">
                            <Sparkles size={17} />
                            <h3>{t("roomDetail.amenities")}</h3>
                        </div>
                        <div className="rux-chip-grid">
                            {data.amenities.map((item, i) => (
                                <span className="rux-chip" key={i}>
                                    {item}
                                </span>
                            ))}
                        </div>
                    </article>
                </div>
            </section>
        </AppLayout>
    );
}
