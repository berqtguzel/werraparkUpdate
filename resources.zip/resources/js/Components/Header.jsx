import React from "react";
import { Link, usePage } from "@inertiajs/react";
import ThemeToggle from "./ThemeToggle";
import LanguageSwitcher from "./LanguageSwitcher";
import "../../css/header.css";

export default function Header({ currentRoute }) {
    const { props } = usePage();
    const locale = props?.locale ?? "de";

    const [open, setOpen] = React.useState(false);
    const [mobileSub, setMobileSub] = React.useState(null);

    React.useEffect(() => {
        document.body.style.overflow = open ? "hidden" : "";
        return () => (document.body.style.overflow = "");
    }, [open]);

    const fallbackNav = [
        {
            name: "Home",
            url: locale === "de" ? "/" : `/${locale}`,
            key: "home",
        },

        { name: "Über uns", url: `/${locale}/uber-uns`, key: "uberuns" },

        {
            name: "Galerie",
            url: `/${locale}/galerie`,
            key: "galerie",
        },

        {
            name: "Karriere",
            url: `/${locale}/karriere`,
            key: "karriere",
        },

        {
            name: "Kontakt",
            url: `/${locale}/kontakt`,
            key: "kontakt",
        },

        { name: "Impressum", url: `/${locale}/impressum`, key: "impressum" },
    ];

    const desktopNav = fallbackNav;
    const mobileNav = fallbackNav;

    return (
        <header className="wh-header">
            <div className="wh-topbar">
                <div className="wh-container wh-topbar__inner">
                    <div className="wh-topbar__left">
                        <a
                            href="mailto:info@werrapark.de"
                            className="wh-toplink"
                        >
                            info@werrapark.de
                        </a>

                        <a href="tel:+4936874205706" className="wh-toplink">
                            036874 205706
                        </a>
                    </div>

                    <div className="wh-topbar__right">
                        <LanguageSwitcher locale={locale} />
                        <ThemeToggle />
                    </div>
                </div>
            </div>

            <div className="wh-navwrap">
                <div className="wh-container wh-nav__inner">
                    <Link href="/" className="wh-brand">
                        <img
                            src="/images/Logo/werrapark-logo-white.png"
                            className="wh-brand__logo wh-brand__logo--light"
                        />

                        <img
                            src="/images/Logo/werrapark-logo.png"
                            className="wh-brand__logo wh-brand__logo--dark"
                        />
                    </Link>

                    <nav className="wh-nav-desktop">
                        {desktopNav.map((n, i) => {
                            const hasChildren = n.children?.length;

                            return (
                                <div key={i} className="wh-nav-item">
                                    <Link
                                        href={n.url}
                                        className={`wh-link ${currentRoute === n.key ? "is-active" : ""}`}
                                    >
                                        {n.name}

                                        {hasChildren && (
                                            <span className="wh-arrow">▾</span>
                                        )}
                                    </Link>

                                    {hasChildren && (
                                        <div className="wh-dropdown">
                                            {n.children.map((c, j) => (
                                                <Link
                                                    key={j}
                                                    href={c.url}
                                                    className="wh-dropdown-link"
                                                >
                                                    {c.name}
                                                </Link>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </nav>

                    <div className="wh-nav-ctas wh-ctas-desktop">
                        <a
                            href="https://bookings.tripmakery.com/de/h/brV2ODN9RoGB?p=1&s=INTERNAL_RATING&a=0&c=0"
                            className="wh-btn wh-btn--light"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            Gruppenbuchung
                        </a>
                        <a
                            href="https://www.secure-hotel-booking.com/d-edge/Werrapark-Hotels-Masserberg-GmbH-Co-KG/JKR8/tr-TR?_gl=1*1b09wi9*_gcl_au*MTUzMDE3MDYyMy4xNzY2NjQ3NjY1"
                            className="wh-btn wh-btn--primary"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            Bestpreis buchen
                        </a>
                    </div>
                    <button
                        className="wh-hamburger"
                        onClick={() => setOpen(true)}
                    >
                        <span />
                        <span />
                        <span />
                    </button>
                </div>
            </div>

            <div className={`wh-drawer ${open ? "is-open" : ""}`}>
                <button
                    className="wh-drawer__backdrop"
                    onClick={() => setOpen(false)}
                />

                <aside className="wh-drawer__panel">
                    <div className="wh-drawer__head">
                        <Link
                            href="/"
                            onClick={() => setOpen(false)}
                            className="wh-brand"
                        >
                            <img
                                src="/images/Logo/werrapark-logo-white.png"
                                className="wh-brand__logo wh-brand__logo--light"
                            />

                            <img
                                src="/images/Logo/werrapark-logo.png"
                                className="wh-brand__logo wh-brand__logo--dark"
                            />
                        </Link>

                        <button
                            className="wh-close"
                            onClick={() => setOpen(false)}
                        >
                            ×
                        </button>
                    </div>

                    <div className="wh-drawer__body">
                        {mobileNav.map((n, i) => {
                            const hasChildren = n.children?.length;

                            return (
                                <div key={i}>
                                    <button
                                        className="wh-m-link"
                                        onClick={() =>
                                            hasChildren
                                                ? setMobileSub(
                                                      mobileSub === i
                                                          ? null
                                                          : i,
                                                  )
                                                : setOpen(false)
                                        }
                                    >
                                        {n.name}

                                        {hasChildren && <span>▾</span>}
                                    </button>

                                    {hasChildren && mobileSub === i && (
                                        <div className="wh-m-sub">
                                            {n.children.map((c, j) => (
                                                <Link
                                                    key={j}
                                                    href={c.url}
                                                    className="wh-m-sublink"
                                                    onClick={() =>
                                                        setOpen(false)
                                                    }
                                                >
                                                    {c.name}
                                                </Link>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                        <div className="wh-m-ctas">
                            <LanguageSwitcher locale={locale} />
                            <a
                                href="https://bookings.tripmakery.com/de/h/brV2ODN9RoGB?p=1&s=INTERNAL_RATING&a=0&c=0"
                                className="wh-btn wh-btn--light wh-btn--block"
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={() => setOpen(false)}
                            >
                                Gruppenbuchung
                            </a>

                            <a
                                href="https://www.secure-hotel-booking.com/d-edge/Werrapark-Hotels-Masserberg-GmbH-Co-KG/JKR8/tr-TR/HotelSelection?_gl=1*1b09wi9*_gcl_au*MTUzMDE3MDYyMy4xNzY2NjQ3NjY1"
                                className="wh-btn wh-btn--primary wh-btn--block"
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={() => setOpen(false)}
                            >
                                Bestpreis buchen
                            </a>
                        </div>
                    </div>
                </aside>
            </div>
        </header>
    );
}
