"use client";

import React from "react";
import { Link, usePage } from "@inertiajs/react";
import { FiCheck, FiMapPin, FiChevronRight } from "react-icons/fi";
import "../../../css/rooms-showcase.css";
import { ROOM_LIST } from "@/Data/RoomsData";
import { useTranslation } from "@/i18n";

const DotGrid = React.lazy(() =>
    import("../ReactBits/Backgrounds/DotGrid").then((m) => ({
        default: m.default || m,
    })),
);

const DATA = {
    title: "Unsere besten Zimmer",
    intro: "Wir bieten Ihnen in unserem exklusiven Hotel eine unvergessliche Erfahrung – vereint mit Komfort und Design. Entspannen Sie in modern gestalteten Zimmern.",
    hotels: [
        ...ROOM_LIST.map((r) => ({
            id: r.id,
            name: r.hotelName,
            location: r.location,
            image: r.heroImage,
            cta: { label: "Hotel Erkunden", slug: r.id },
            items: r.roomTypes,
        })),
    ],
};

const Title = ({ children }) => <h2 className="rs-title">{children}</h2>;
const Eyebrow = ({ children }) => <div className="rs-eyebrow">{children}</div>;

const HotelCard = ({ hotel, locale }) => {
    const { t } = useTranslation();
    const href =
        hotel.cta?.slug && locale
            ? `/${locale}/rooms/${hotel.cta.slug}`
            : hotel.cta?.href || "/rooms";

    return (
        <article className="rs-card" aria-labelledby={`h-${hotel.id}`}>
            {hotel.image && (
                <>
                    <img
                        className="rs-card__media"
                        src={hotel.image}
                        alt=""
                        aria-hidden="true"
                    />
                    <span className="rs-card__shade" aria-hidden="true" />
                </>
            )}

            <div className="rs-card__head">
                <div className="rs-card__meta">
                    <FiMapPin className="rs-icon" aria-hidden />
                    <span>{hotel.location}</span>
                </div>
                <h3 id={`h-${hotel.id}`} className="rs-card__title">
                    {hotel.name}
                </h3>
            </div>

            <ul className="rs-list">
                {hotel.items.map((item, i) => (
                    <li key={i}>
                        <FiCheck className="rs-icon" aria-hidden />
                        <span>{item}</span>
                    </li>
                ))}
            </ul>

            <Link className="rs-cta" href={href}>
                {t("rooms.explore")}
                <FiChevronRight />
            </Link>
        </article>
    );
};

export default function RoomsShowcase({ data = DATA }) {
    const [mounted, setMounted] = React.useState(false);
    React.useEffect(() => setMounted(true), []);

    const { props } = usePage();
    const locale = props?.locale ?? "de";
    const { t } = useTranslation();

    return (
        <section className="rs-wrap rs-with-bg" aria-labelledby="rooms-title">
            {mounted && (
                <React.Suspense fallback={null}>
                    <div
                        className="rs-dotgrid"
                        aria-hidden="true"
                        style={{
                            position: "absolute",
                            inset: 0,
                            zIndex: 0,
                            pointerEvents: "none",
                            overflow: "hidden",
                        }}
                    >
                        <DotGrid
                            dotSize={12}
                            gap={80}
                            baseColor="#1f7008"
                            activeColor="#0E9B5B"
                            proximity={150}
                            speedTrigger={110}
                            shockRadius={260}
                            shockStrength={5}
                            maxSpeed={5200}
                            resistance={820}
                            returnDuration={1.3}
                        />
                    </div>
                </React.Suspense>
            )}

            <div className="rs-top">
                <Eyebrow>{t("rooms.eyebrow")}</Eyebrow>
                <Title id="rooms-title">{t("rooms.title")}</Title>
                <p className="rs-intro">{t("rooms.intro")}</p>
            </div>

            <div className="rs-grid">
                {data.hotels.map((h) => (
                    <HotelCard key={h.id} hotel={h} locale={locale} />
                ))}
            </div>
        </section>
    );
}
